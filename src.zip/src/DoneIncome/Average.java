package DoneIncome;

import java.util.HashMap;

public class Average {
	public static Integer average = 0;
	public static HashMap<String, Integer> avglist = new HashMap<>();		//�洢���һ��ͬ���͵�ֵ
}
