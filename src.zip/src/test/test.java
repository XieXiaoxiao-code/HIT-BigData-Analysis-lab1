package test;

import org.ujmp.core.Matrix;

public class test {
	public static void main(String[] args) {
		Matrix a = Matrix.Factory.ones(4, 4);
		System.out.println(a);
	}

}
