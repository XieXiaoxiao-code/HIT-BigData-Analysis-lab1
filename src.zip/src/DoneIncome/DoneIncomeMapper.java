package DoneIncome;
import java.io.IOException;

import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class DoneIncomeMapper
    extends Mapper<LongWritable, Text, Text, Text>{
    public void map(LongWritable key, Text value, Context context) throws IOException, InterruptedException{
        String line = value.toString();
        String[] words = line.split("\\|");
        String K = words[9]+"&"+words[10];
        if((!words[11].equals("?"))&&(!Average.avglist.containsKey(K))) {
        	Average.avglist.put(K, Integer.parseInt(words[11]));
        }
        context.write(new Text(K), value);
    }
}