package Done;
import java.io.IOException;

import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class DoneMapper
    extends Mapper<LongWritable, Text, Text, Text>{
    public void map(LongWritable key, Text value, Context context) throws IOException, InterruptedException{
        String line = value.toString();
        String[] words = line.split("\\|");
        if (!words[6].equals("?")) {
        	Done.longitude.add(Double.parseDouble(words[1]));
        	Done.latitude.add(Double.parseDouble(words[2]));
        	Done.altitude.add(Double.parseDouble(words[3]));
        	Done.rating.add(Double.parseDouble(words[6]));
        	Done.user_income.add(Double.parseDouble(words[11]));
        }
        context.write(new Text(key.toString()), value);
    }
}