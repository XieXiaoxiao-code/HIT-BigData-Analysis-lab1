package test;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class FtoC {
	
	public String ftoc(String s) {
		Pattern pattern1 = Pattern.compile("-*[0-9]+.[0-9]+��");
		Pattern pattern2 = Pattern.compile("-*[0-9]+.[0-9]+�H");
		Pattern number = Pattern.compile("-*[0-9]+.[0-9]+");
		double num = 0;
		
		Matcher m1 = pattern1.matcher(s);
		Matcher m2 = pattern2.matcher(s);
		Matcher m3;
		
		if (m2.find()) {
			m3 = number.matcher(s);
			m3.find();
			num = Float.parseFloat(m3.group());
			num = ((num - 32.0)/1.8);
			return String.format("%.1f", num)+"��";
		}
		
		else if (m1.find()) {
			return s;
		}
		
		else {
			return "Error Input Format!";
		}
		
	}

}
