package Filter2;
import java.io.IOException;

import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

public class FilterReducer2
    extends Reducer<Text, Text, NullWritable, Text>{
	Double min_rate = Filter2.min_rate;
	Double max_rate = Filter2.max_rate;
    
    public void reduce(Text key, Iterable<Text> values, Context context)
        throws IOException, InterruptedException{
    	for (Text text:values) {
    		String[] words = text.toString().split("\\|");
    		
    		if (!words[6].toString().equals("?")) {					//���ǵ�ȱʧֵ"?"
        		Double rate = Double.parseDouble(words[6]);
        		rate = (rate-min_rate)/(max_rate-min_rate);
        		words[6] = String.format("%.2f", rate);
    		}
    		
            String line = words[0];
            for (int i=1;i<words.length;i++) {
            	line = line+"|"+words[i];
            }
            context.write(NullWritable.get(), new Text(line));    	
    	}
    }
}