package Filter;
import java.io.IOException;

import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

public class FilterReducer
    extends Reducer<Text, Text, NullWritable, Text>{
    
    public void reduce(Text key, Iterable<Text> values, Context context)
        throws IOException, InterruptedException{
    	String[] lola = key.toString().split("&");
    	Float longitude = Float.parseFloat(lola[0]);
    	Float latitude = Float.parseFloat(lola[1]);
    	
        for(Text value: values){
        	if ((longitude>=8.1461259&&longitude<=11.1993265)
        			&&(latitude>=56.5824856&&latitude<=57.750511)) {
                context.write(NullWritable.get(), new Text(value.toString()));
        	}
        }
    }
}