package Filter2;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class DateFormatChange {
	
	public static String month(String m) {
		if (m.equals("January")) {
			return "01";
		}
		
		else if (m.equals("February")) {
			return "02";
		}
		
		else if (m.equals("March")) {
			return "03";
		}
		
		else if (m.equals("April")) {
			return "04";
		}
		
		else if (m.equals("May")) {
			return "05";
		}
		
		else if (m.equals("June")) {
			return "06";
		}
		
		else if (m.equals("July")) {
			return "07";
		}
		
		else if (m.equals("August")) {
			return "08";
		}
		
		else if (m.equals("September")) {
			return "09";
		}
		
		else if (m.equals("October")) {
			return "10";
		}
		
		else if (m.equals("November")) {
			return "11";
		}
		
		else if (m.equals("December")) {
			return "12";
		}
		
		else {
			return "Error Input!";
		}
	}
	
	public static String change(String s) {
		Pattern pattern1 = Pattern.compile("[A-Za-z]+[ ][0-9]+[,][0-9]{4}");
		Pattern pattern2 = Pattern.compile("[0-9]{4}/[0-9]{2}/[0-9]{2}");
		Pattern pattern3 = Pattern.compile("[0-9]{4}-[0-9]{2}-[0-9]{2}");
		Pattern month = Pattern.compile("[A-Za-z]+");
		Pattern number = Pattern.compile("[0-9]+");
		Matcher m1 = pattern1.matcher(s);
		Matcher m2 = pattern2.matcher(s);
		Matcher m3 = pattern3.matcher(s);
		StringBuilder re = new StringBuilder();
		if (m1.find()) {							//April 03,2001��ʽ
			Matcher mon = month.matcher(s);
			mon.find();
			String b = month(mon.group());
			Matcher num1 = number.matcher(s);
			num1.find();
			String c = num1.group();
			num1.find();
			String a = num1.group();
			re.append(a);
			re.append("-");
			re.append(b);
			re.append("-");
			re.append(c);
		}
		
		else if (m2.find()) {						//2001/04/03��ʽ
			Matcher num2 = number.matcher(s);
			num2.find();
			re.append(num2.group());
			re.append("-");
			num2.find();
			re.append(num2.group());
			re.append("-");
			num2.find();
			re.append(num2.group());
		}
		
		else if(m3.find()) {									//2001-04-03��׼��ʽ
			return s;
		}
		
		else {
			return "Error Input Format!";
		}
		
		return re.toString();
	}

}
