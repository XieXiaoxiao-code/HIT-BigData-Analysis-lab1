package Done;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;

import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

public class DoneReducer
    extends Reducer<Text, Text, NullWritable, Text>{
	
	public static Double RATE(Double longitude, Double latitude, Double altitude, Double user_income) {
		int index=0;
		Double min_rate1 = Double.MAX_VALUE;
		Double min_rate2 = Double.MAX_VALUE;
		Double min_rate3 = Double.MAX_VALUE;
		Double min_rate4 = Double.MAX_VALUE;
		Double min_rate = Double.MAX_VALUE;
		for (int i=0;i<Done.longitude.size();i++) {
			if (Math.abs((Done.longitude.get(i)-longitude)/longitude)<=min_rate){
				min_rate1 = Math.abs((Done.longitude.get(i)-longitude)/longitude);
			}

			if (Math.abs((Done.latitude.get(i)-latitude)/latitude)<=min_rate){
				min_rate2 = Math.abs((Done.latitude.get(i)-latitude)/latitude);
			}

			if (Math.abs((Done.altitude.get(i)-altitude)/altitude)<=min_rate){
				min_rate3 = Math.abs((Done.altitude.get(i)-altitude)/altitude);
			}

			if (Math.abs((Done.user_income.get(i)-user_income)/user_income)<=min_rate){
				min_rate4 = Math.abs((Done.user_income.get(i)-user_income)/user_income);
			}
			ArrayList<Double> compare = new ArrayList<Double>();
			compare.add(min_rate1);
			compare.add(min_rate2);
			compare.add(min_rate3);
			compare.add(min_rate4);
			if(min_rate >= Collections.max(compare)) {
				index = i;
			}
		}
		return Done.rating.get(index);
	}
	    
    public void reduce(Text key, Iterable<Text> values, Context context)
        throws IOException, InterruptedException{
		String[] words;
    	for (Text text: values) {
    		words = text.toString().split("\\|");
    		if (!words[6].equals("?")) {
    			context.write(NullWritable.get(), text);
    		}
    		else {
    			words[6] = String.format("%.2f", RATE(Double.parseDouble(words[1]), Double.parseDouble(words[2]), Double.parseDouble(words[3]), Double.parseDouble(words[11])));
                String line = words[0];
                for (int i=1;i<words.length;i++) {
                	line = line+"|"+words[i];
                }
                context.write(NullWritable.get(), new Text(line));
    		}
    	}
    }
}