package Filter2;
import java.io.IOException;

import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class FilterMapper2
    extends Mapper<LongWritable, Text, Text, Text>{
    public void map(LongWritable key, Text value, Context context) throws IOException, InterruptedException{
        String line = value.toString();
        String[] words = line.split("\\|");
        String review_date = words[4];
        String tem = words[5];
        String user_birthday = words[8];
        
        if (!words[6].toString().equals("?")) {						//�ų�ȱʧֵ��Ӱ��
            Double rate = Double.parseDouble(words[6]);
            if (rate>=Filter2.max_rate) {
            	Filter2.max_rate = Double.valueOf(rate);
            }
            if (rate<=Filter2.min_rate) {
            	Filter2.min_rate = Double.valueOf(rate);
            }
        }
        words[4] = DateFormatChange.change(review_date);
        words[8] = DateFormatChange.change(user_birthday);
        words[5] = FtoC.ftoc(tem);
        line = "";
        line = words[0];
        for (int i=1;i<words.length;i++) {
        	line = line+"|"+words[i];
        }
        context.write(new Text(key.toString()), new Text(line));
    }
}