package Sample;
import java.io.IOException;

import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

public class StratifiedSamplingReducer
    extends Reducer<Text, Text, NullWritable, Text>{
    
    public void reduce(Text key, Iterable<Text> values, Context context)
        throws IOException, InterruptedException{
        int i=0;
        for(Text value: values){
        	if (i%100==0) {
                context.write(NullWritable.get(), new Text(value.toString()));
        	}
        	i=i+1;
        }
    }
}